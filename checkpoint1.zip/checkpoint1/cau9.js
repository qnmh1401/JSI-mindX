var m = [1,2,3,4,5,6,"hh", "9",80,100]
m.slice()
const arrM2 = m.map((value,index) => {
    if(value === NaN(value)){
        return value.splice(NaN(value),)
    }
})

console.log(arrM2)